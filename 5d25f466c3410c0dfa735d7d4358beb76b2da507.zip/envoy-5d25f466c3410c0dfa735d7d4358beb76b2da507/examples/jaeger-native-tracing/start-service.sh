#!/usr/bin/env bash
/install-jaeger-plugin.sh
/usr/local/bin/start_service.sh
