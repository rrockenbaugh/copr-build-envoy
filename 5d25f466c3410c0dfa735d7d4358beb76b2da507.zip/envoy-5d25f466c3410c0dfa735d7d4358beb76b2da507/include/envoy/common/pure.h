#pragma once

namespace Envoy {
/**
 * Friendly name for a pure virtual routine.
 */
#define PURE = 0
} // namespace Envoy
