Protocol buffer definitions for filters.

Visibility of the definitions should be constrained to none except for
shared definitions between explicitly enumerated filters (e.g. accesslog and fault definitions).
