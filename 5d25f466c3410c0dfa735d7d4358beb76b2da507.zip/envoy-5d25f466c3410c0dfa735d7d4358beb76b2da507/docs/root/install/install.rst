.. _install:

Building and installation
=========================

.. toctree::
  :maxdepth: 2

  building
  ref_configs
  tools/tools
