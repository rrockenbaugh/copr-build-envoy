.. _config_network_filters_echo_v1:

Echo
====

Echo :ref:`configuration overview <config_network_filters_echo>`.

.. code-block:: json

  {
    "name": "echo",
    "config": {}
  }
