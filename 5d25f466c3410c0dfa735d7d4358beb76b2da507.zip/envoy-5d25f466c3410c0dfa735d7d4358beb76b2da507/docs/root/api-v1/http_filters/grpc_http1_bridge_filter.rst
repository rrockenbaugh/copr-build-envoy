.. _config_http_filters_grpc_bridge_v1:

gRPC HTTP/1.1 bridge
====================

gRPC HTTP/1.1 bridge :ref:`configuration overview <config_http_filters_grpc_bridge>`.

.. code-block:: json

  {
    "name": "grpc_http1_bridge",
    "config": {}
  }
