.. _config_http_filters_grpc_web_v1:

gRPC-Web filter
===============

gRPC-Web filter :ref:`configuration overview <config_http_filters_grpc_web>`.

.. code-block:: json

  {
    "name": "grpc_web",
    "config": {}
  }
