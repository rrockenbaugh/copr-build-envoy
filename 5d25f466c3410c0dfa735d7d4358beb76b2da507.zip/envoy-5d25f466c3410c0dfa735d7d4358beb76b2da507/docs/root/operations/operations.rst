.. _operations:

Operations and administration
=============================

.. toctree::
  :maxdepth: 2

  cli
  hot_restarter
  admin
  stats_overview
  runtime
  fs_flags
  traffic_capture
