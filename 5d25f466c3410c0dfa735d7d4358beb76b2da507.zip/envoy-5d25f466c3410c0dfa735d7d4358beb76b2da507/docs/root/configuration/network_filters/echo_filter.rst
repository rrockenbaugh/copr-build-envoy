.. _config_network_filters_echo:

Echo
====

The echo is a trivial network filter mainly meant to demonstrate the network filter API. If
installed it will echo (write) all received data back to the connected downstream client.

* :ref:`v1 API reference <config_network_filters_echo_v1>`
* :ref:`v2 API reference <envoy_api_field_listener.Filter.name>`
