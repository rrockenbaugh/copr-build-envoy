.. _config_thrift_filters:

Thrift filters
===============

Envoy has the following builtin Thrift filters.

.. toctree::
  :maxdepth: 2

  router_filter
